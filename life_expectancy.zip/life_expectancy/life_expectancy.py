"""
File Name: life_expectancy.py
Author: Ntyam Adjomo Francky Ludovic

Purpose: write a program to analyze a dataset containing information about life expectancies over the years throughout the countries of the world.

This program also contains a way to Showing Creativity and Exceeding Requirements.
"""
# list where we will add all the value for life expectancy in dataset.
value_life_expectancy = []

with open("life_expectancy/life-expectancy.csv") as dataset:
    for line in dataset:
        line = line.strip()
        parts = line.split(",")
        value_life_expectancy.append(parts[len(parts) - 1])
value_life_expectancy.pop(0)
print(f"The overall max life expectancy is: {max(value_life_expectancy)}")
print(f"The overall min life expectancy is: {min(value_life_expectancy)}")   

